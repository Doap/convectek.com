<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?><?php echo et_fable_get_background(); ?>>
	<div class="container clearfix">
		<header class="entry-title">
			<h1><?php the_title(); ?></h1>
		</header>
	</div> <!-- .container -->
</article> <!-- .entry-->