	<?php get_sidebar( 'footer' ); ?>

	<p id="footer-info"><?php printf( __( 'Designed by %1$s | Powered by %2$s', 'Fable' ), '<a href="http://www.elegantthemes.com" title="Premium WordPress Themes">Elegant Themes</a>', '<a href="http://www.wordpress.org">WordPress</a>' ); ?></p>

	<?php wp_footer(); ?>
</body>
</html>