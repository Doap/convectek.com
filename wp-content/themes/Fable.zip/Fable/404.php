<?php get_header(); ?>

<?php get_template_part( 'includes/no-results', '404' ); ?>

<?php get_footer(); ?>