(function($){
	$(document).ready(function() {
		$( 'label #et_fullwidthpage' ).closest( 'div' ).css({ 'visibility': 'hidden', 'display': 'none' });
	});
})(jQuery)