<?php get_header(); ?>

<div id="main-content" class="et-no-big-image">
	<article class="entry-content clearfix">
		<?php get_template_part('includes/no-results','404'); ?>
	</article>
</div> <!-- #main-content -->

<?php get_footer(); ?>