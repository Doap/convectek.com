				</div> <!-- #main-content -->
			</div> <!-- #main-area -->
			<div id="main-area-bottom"></div>

			<div id="footer">
				<p id="copyright"><?php esc_html_e('Designed by ','eStore'); ?> <a href="http://www.elegantthemes.com" title="Elegant Themes">Elegant Themes</a> | <?php esc_html_e('Powered by ','eStore'); ?> <a href="http://www.wordpress.org">Wordpress</a></p>
			</div> <!-- #footer-->

		</div> <!-- .container -->
	</div> <!-- #content -->

	<?php get_template_part('includes/scripts'); ?>
	<?php wp_footer(); ?>

</body>
</html>