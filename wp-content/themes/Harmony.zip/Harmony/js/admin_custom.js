(function($){
	$(document).ready( function(){
		$('.et_event_date').datepicker( {
			dateFormat: 'D, M d, yy',
			showAnim : 'slideDown'
		} );
	} );
})(jQuery)