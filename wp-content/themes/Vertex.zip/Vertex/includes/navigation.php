<div class="pagination container clearfix">
	<div class="alignleft"><?php next_posts_link(esc_html__('&laquo; Older Entries','Vertex')) ?></div>
	<div class="alignright"><?php previous_posts_link(esc_html__('Next Entries &raquo;', 'Vertex')) ?></div>
</div>