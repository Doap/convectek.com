=== Doap Language Translator ===
Contributors: David Menache, Shawn Crowe
Donate link: http://www.doap.com
Plugin link: http://www.doap.com/dlt
Tags: Doap

Requires at least: 2.9
Tested up to: 4.0
stable tag: 4.0.9

Welcome to Doap Language Translator! 

== Description ==

Adds a USA/Nicaragua flag widget.

