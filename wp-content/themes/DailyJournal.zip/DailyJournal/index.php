<?php get_header(); ?>

<?php get_template_part('includes/entry','home'); ?>

<?php get_footer(); ?>